===========================
SnowLight
===========================
-----------
Description
-----------
SnowLight is a minimlist version of SnowFlat responsive theme for Question2Answer

------------
Installation
------------
1. Upload the theme in qa-theme folder.
1. Select the theme SnowLight on General page in admin section.

-----------
Disclaimer
-----------
The changes are mostly cosmetic. It is probably okay for production environments, but may not work exactly as expected. Refunds will not be given. If it breaks, you get to keep both parts.
